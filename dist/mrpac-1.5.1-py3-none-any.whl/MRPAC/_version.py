"""Version information for MRPAC"""

__version__ = "1.5.1"
