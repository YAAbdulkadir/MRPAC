"""Version information for MRPAC"""

__version__ = "1.6.1"
