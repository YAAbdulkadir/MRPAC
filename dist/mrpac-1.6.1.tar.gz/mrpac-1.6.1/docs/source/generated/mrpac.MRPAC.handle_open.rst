mrpac.MRPAC.handle\_open
========================

.. currentmodule:: mrpac.MRPAC

.. autofunction:: handle_open