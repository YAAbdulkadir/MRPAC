mrpac.MRPAC.handle\_close
=========================

.. currentmodule:: mrpac.MRPAC

.. autofunction:: handle_close