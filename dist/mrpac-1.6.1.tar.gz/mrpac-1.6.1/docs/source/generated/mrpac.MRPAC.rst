mrpac.MRPAC
===========

.. automodule:: mrpac.MRPAC
  
   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:                                          
   
      databaseSetup
      handle_close
      handle_open
      handle_store
      main
      send_c_store
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:                                          
      :template: custom-class-template.rst               
   
      AddScreen
      ConfigScreen
      EditScreen
      LoginScreen
      SetupScreen
      VerifyScreen
   
   

   
   
   



