mrpac.MRPAC.databaseSetup
=========================

.. currentmodule:: mrpac.MRPAC

.. autofunction:: databaseSetup