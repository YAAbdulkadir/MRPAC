mrpac.AutocontourMR.AutocontourMR
=================================

.. currentmodule:: mrpac.AutocontourMR

.. autoclass:: AutocontourMR
   :members:                                    
   :show-inheritance:                           
   :inherited-members:                          

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~AutocontourMR.__init__
      ~AutocontourMR.run
   
   

   
   
   