mrpac.RTstruct.RTstruct
=======================

.. currentmodule:: mrpac.RTstruct

.. autoclass:: RTstruct
   :members:                                    
   :show-inheritance:                           
   :inherited-members:                          

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~RTstruct.__init__
      ~RTstruct.add_contour
      ~RTstruct.add_series_description
      ~RTstruct.add_structure_set_name
      ~RTstruct.build
      ~RTstruct.change_instance_uid
      ~RTstruct.change_media_storage_uid
      ~RTstruct.save_as
   
   

   
   
   