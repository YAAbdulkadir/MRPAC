mrpac.DICOM\_Networking.StorageSCP
==================================

.. currentmodule:: mrpac.DICOM_Networking

.. autoclass:: StorageSCP
   :members:                                    
   :show-inheritance:                           
   :inherited-members:                          

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~StorageSCP.__init__
      ~StorageSCP.set_handlers
      ~StorageSCP.start
      ~StorageSCP.stop
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~StorageSCP.slices_path
   
   