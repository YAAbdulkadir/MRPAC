mrpac.Utils.autocontour\_rectum
===============================

.. currentmodule:: mrpac.Utils

.. autofunction:: autocontour_rectum