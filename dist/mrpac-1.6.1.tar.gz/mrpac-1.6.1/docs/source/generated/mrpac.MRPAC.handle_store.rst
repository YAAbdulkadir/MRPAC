mrpac.MRPAC.handle\_store
=========================

.. currentmodule:: mrpac.MRPAC

.. autofunction:: handle_store