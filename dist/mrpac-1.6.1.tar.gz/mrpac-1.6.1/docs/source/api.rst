API References
==============

.. autosummary::
   :toctree: generated
   :template: custom-module-template.rst
   :recursive:

   mrpac