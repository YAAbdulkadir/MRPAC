mrpac.MRPAC.send\_c\_store
==========================

.. currentmodule:: mrpac.MRPAC

.. autofunction:: send_c_store