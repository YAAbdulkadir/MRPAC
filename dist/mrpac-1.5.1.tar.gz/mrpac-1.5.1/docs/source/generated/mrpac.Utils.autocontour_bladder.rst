mrpac.Utils.autocontour\_bladder
================================

.. currentmodule:: mrpac.Utils

.. autofunction:: autocontour_bladder