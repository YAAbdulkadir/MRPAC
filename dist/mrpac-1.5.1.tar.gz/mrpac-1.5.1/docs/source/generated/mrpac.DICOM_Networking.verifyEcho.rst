mrpac.DICOM\_Networking.verifyEcho
==================================

.. currentmodule:: mrpac.DICOM_Networking

.. autofunction:: verifyEcho