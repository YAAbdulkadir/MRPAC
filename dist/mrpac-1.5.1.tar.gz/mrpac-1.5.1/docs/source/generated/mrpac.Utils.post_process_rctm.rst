mrpac.Utils.post\_process\_rctm
===============================

.. currentmodule:: mrpac.Utils

.. autofunction:: post_process_rctm