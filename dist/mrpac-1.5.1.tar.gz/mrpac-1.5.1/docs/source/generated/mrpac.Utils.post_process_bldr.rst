mrpac.Utils.post\_process\_bldr
===============================

.. currentmodule:: mrpac.Utils

.. autofunction:: post_process_bldr