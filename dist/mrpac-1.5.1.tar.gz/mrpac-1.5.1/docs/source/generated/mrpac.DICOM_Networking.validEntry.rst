mrpac.DICOM\_Networking.validEntry
==================================

.. currentmodule:: mrpac.DICOM_Networking

.. autofunction:: validEntry