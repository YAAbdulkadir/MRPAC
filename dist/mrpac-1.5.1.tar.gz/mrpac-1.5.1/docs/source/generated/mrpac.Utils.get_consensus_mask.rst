mrpac.Utils.get\_consensus\_mask
================================

.. currentmodule:: mrpac.Utils

.. autofunction:: get_consensus_mask