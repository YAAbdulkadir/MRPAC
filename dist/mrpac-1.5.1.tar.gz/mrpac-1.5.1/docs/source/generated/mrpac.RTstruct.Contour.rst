mrpac.RTstruct.Contour
======================

.. currentmodule:: mrpac.RTstruct

.. autoclass:: Contour
   :members:                                    
   :show-inheritance:                           
   :inherited-members:                          

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Contour.__init__
      ~Contour.add_mask
      ~Contour.change_color
      ~Contour.change_line_thickness
      ~Contour.change_name
      ~Contour.change_opacity
      ~Contour.change_thickness
      ~Contour.contour_generation_algorithm
   
   

   
   
   