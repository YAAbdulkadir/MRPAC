mrpac.Utils.load\_scan
======================

.. currentmodule:: mrpac.Utils

.. autofunction:: load_scan