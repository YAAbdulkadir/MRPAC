mrpac.DICOM\_Networking.pingTest
================================

.. currentmodule:: mrpac.DICOM_Networking

.. autofunction:: pingTest