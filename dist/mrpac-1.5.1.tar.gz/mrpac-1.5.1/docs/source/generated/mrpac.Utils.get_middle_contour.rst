mrpac.Utils.get\_middle\_contour
================================

.. currentmodule:: mrpac.Utils

.. autofunction:: get_middle_contour