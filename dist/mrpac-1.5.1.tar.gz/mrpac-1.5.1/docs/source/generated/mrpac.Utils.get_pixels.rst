mrpac.Utils.get\_pixels
=======================

.. currentmodule:: mrpac.Utils

.. autofunction:: get_pixels