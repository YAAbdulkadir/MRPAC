mrpac.MRPAC.main
================

.. currentmodule:: mrpac.MRPAC

.. autofunction:: main